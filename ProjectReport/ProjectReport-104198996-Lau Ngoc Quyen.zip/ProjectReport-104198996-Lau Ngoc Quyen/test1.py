import random

def generate_random_list(size, value_range):
    return [random.randint(*value_range) for _ in range(size)]

# Example usage
list_1 = generate_random_list(10, (0, 100))
list_2 = generate_random_list(5, (-50, 50))

print("Random List 1:", list_1)
print("Random List 2:", list_2)


