import random

def generate_random_expression():
    operators = ['+', '-', '*', '/']
    num1 = random.randint(0, 100)
    num2 = random.randint(1, 100)  # Avoid division by zero
    op = random.choice(operators)
    return f"{num1} {op} {num2}"

# Example usage
expression_1 = generate_random_expression()
expression_2 = generate_random_expression()

print("Random Expression 1:", expression_1)
print("Random Expression 2:", expression_2)


