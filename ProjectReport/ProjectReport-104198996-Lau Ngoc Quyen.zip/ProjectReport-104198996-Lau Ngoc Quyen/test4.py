import random

# Generate a random list of intergers
test_case1 = [random.randint(0, 100) for _ in range(10)]
print("Test case 1:", test_case1) 






# Generate another random list of intergers
test_case2 = [random.randint(-50, 50) for _ in range(10)] 
print("Test case 2:", test_case2)